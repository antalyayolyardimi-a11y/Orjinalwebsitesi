# ================== WEB APPLICATION ==================
"""
FastAPI tabanlı web uygulaması - Trading sinyalleri için modern web arayüzü
"""

import asyncio
import json
import time
from datetime import datetime
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Form, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import uvicorn

from config.settings import get_settings
from utils.helpers import log
from indicators.technical import get_technical_data
from web.bot_manager import bot_manager


class WebTradingBot:
    """Web tabanlı Trading Bot"""
    
    def __init__(self, trading_bot_instance):
        self.trading_bot = trading_bot_instance
        self.app = FastAPI(title="Advanced Trading Bot", version="2.0.0")
        
        # Templates ve static files
        self.templates = Jinja2Templates(directory="web/templates")
        self.app.mount("/static", StaticFiles(directory="web/static"), name="static")
        
        # WebSocket connections
        self.active_connections: List[WebSocket] = []
        
        # Signal storage
        self.signals_history: List[Dict[str, Any]] = []
        self.current_signals: List[Dict[str, Any]] = []
        
        # Bot state
        self.is_running = False
        self.current_mode = "balanced"
        self.stats = {
            "total_scans": 0,
            "signals_sent": 0,
            "last_scan": None,
            "uptime": time.time()
        }
        
        # Setup routes
        self._setup_routes()
    
    def _setup_routes(self):
        """Route'ları ayarla"""
        
        @self.app.get("/", response_class=HTMLResponse)
        async def dashboard(request: Request):
            """Ana dashboard"""
            return self.templates.TemplateResponse("dashboard.html", {
                "request": request,
                "stats": self.stats,
                "current_mode": self.current_mode,
                "is_running": self.is_running,
                "current_signals": self.current_signals[-10:],  # Son 10 sinyal
                "modes": list(MODE_CONFIGS.keys())
            })
        
        @self.app.get("/signals", response_class=HTMLResponse)
        async def signals_page(request: Request):
            """Sinyaller sayfası"""
            return self.templates.TemplateResponse("signals.html", {
                "request": request,
                "signals": self.signals_history[-50:],  # Son 50 sinyal
                "current_mode": self.current_mode
            })
        
        @self.app.get("/analysis/{symbol}")
        async def symbol_analysis(symbol: str):
            """Sembol analizi"""
            try:
                normalized_symbol = self.trading_bot.symbol_manager.normalize_symbol(symbol.upper())
                
                if not normalized_symbol:
                    raise HTTPException(status_code=404, detail=f"Symbol {symbol} not found")
                
                analysis = await self._analyze_symbol(normalized_symbol)
                return JSONResponse(analysis)
                
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/mode")
        async def change_mode(mode: str = Form(...)):
            """Mode değiştir"""
            if mode not in MODE_CONFIGS:
                raise HTTPException(status_code=400, detail="Invalid mode")
            
            self.current_mode = mode
            self.trading_bot.apply_mode_config(mode)
            
            # WebSocket'lere bildir
            await self._broadcast_message({
                "type": "mode_changed",
                "mode": mode,
                "timestamp": datetime.now().isoformat()
            })
            
            return {"status": "success", "mode": mode}
        
        @self.app.post("/bot/start")
        async def start_bot():
            """Bot'u başlat"""
            if not self.is_running:
                self.is_running = True
                asyncio.create_task(self._run_scanner())
                
                await self._broadcast_message({
                    "type": "bot_status",
                    "status": "started",
                    "timestamp": datetime.now().isoformat()
                })
            
            return {"status": "started"}
        
        @self.app.post("/bot/stop")
        async def stop_bot():
            """Bot'u durdur"""
            self.is_running = False
            
            await self._broadcast_message({
                "type": "bot_status",
                "status": "stopped",
                "timestamp": datetime.now().isoformat()
            })
            
            return {"status": "stopped"}
        
        @self.app.get("/api/stats")
        async def get_stats():
            """İstatistikleri al"""
            ai_stats = ai_predictor.get_stats()
            performance_stats = self.trading_bot.performance.get_stats()
            
            return {
                "bot_stats": self.stats,
                "ai_stats": ai_stats,
                "performance_stats": performance_stats,
                "current_mode": self.current_mode,
                "is_running": self.is_running
            }
        
        @self.app.websocket("/ws")
        async def websocket_endpoint(websocket: WebSocket):
            """WebSocket endpoint"""
            await self._handle_websocket(websocket)
    
    async def _handle_websocket(self, websocket: WebSocket):
        """WebSocket bağlantısını yönet"""
        await websocket.accept()
        self.active_connections.append(websocket)
        
        try:
            # İlk bağlantıda mevcut durumu gönder
            await websocket.send_json({
                "type": "initial_state",
                "stats": self.stats,
                "current_mode": self.current_mode,
                "is_running": self.is_running,
                "current_signals": self.current_signals[-5:]
            })
            
            while True:
                # Keep alive
                await websocket.receive_text()
                
        except WebSocketDisconnect:
            self.active_connections.remove(websocket)
    
    async def _broadcast_message(self, message: Dict[str, Any]):
        """Tüm WebSocket bağlantılarına mesaj gönder"""
        if self.active_connections:
            disconnected = []
            
            for connection in self.active_connections:
                try:
                    await connection.send_json(message)
                except:
                    disconnected.append(connection)
            
            # Kopuk bağlantıları temizle
            for connection in disconnected:
                if connection in self.active_connections:
                    self.active_connections.remove(connection)
    
    async def _run_scanner(self):
        """Scanner'ı çalıştır"""
        while self.is_running:
            try:
                await self._scan_iteration()
                await asyncio.sleep(300)  # 5 dakika bekle
            except Exception as e:
                log(f"❌ Scanner hatası: {e}")
                await asyncio.sleep(30)
    
    async def _scan_iteration(self):
        """Tek bir tarama iterasyonu"""
        self.stats["total_scans"] += 1
        self.stats["last_scan"] = datetime.now().isoformat()
        
        # Trading bot'un scan metodunu kullan
        symbols = self.trading_bot.symbol_manager.get_usdt_pairs(
            self.trading_bot.current_min_volume
        )
        
        if not symbols:
            return
        
        # Tarama yap (basitleştirilmiş)
        candidates = await self.trading_bot._scan_iteration_web()
        
        # Sinyalleri işle
        new_signals = 0
        for candidate in candidates[:3]:  # En iyi 3 adayı al
            if candidate["score"] >= self.trading_bot.dynamic_min_score:
                signal = self._format_signal(candidate)
                
                self.current_signals.append(signal)
                self.signals_history.append(signal)
                
                # WebSocket'lere gönder
                await self._broadcast_message({
                    "type": "new_signal",
                    "signal": signal,
                    "timestamp": datetime.now().isoformat()
                })
                
                new_signals += 1
        
        self.stats["signals_sent"] += new_signals
        
        # İstatistikleri güncelle
        await self._broadcast_message({
            "type": "stats_update",
            "stats": self.stats,
            "timestamp": datetime.now().isoformat()
        })
    
    def _format_signal(self, candidate: Dict[str, Any]) -> Dict[str, Any]:
        """Sinyal formatla"""
        return {
            "id": f"{candidate['symbol']}_{int(time.time())}",
            "symbol": candidate['symbol'],
            "side": candidate['side'],
            "regime": candidate.get('regime', '-'),
            "entry": candidate['entry'],
            "sl": candidate['sl'],
            "tp1": candidate['tps'][0],
            "tp2": candidate['tps'][1],
            "tp3": candidate['tps'][2],
            "score": candidate['score'],
            "reason": candidate.get('reason', ''),
            "timestamp": datetime.now().isoformat(),
            "mode": self.current_mode
        }
    
    async def _analyze_symbol(self, symbol: str) -> Dict[str, Any]:
        """Sembol analizi yap"""
        from config.settings import TF_LTF, TF_HTF, LOOKBACK_LTF, LOOKBACK_HTF
        from indicators.technical import rsi, adx, atr_wilder, bollinger, donchian
        
        # Veri al
        df_ltf = get_ohlcv(self.trading_bot.client, symbol, TF_LTF, LOOKBACK_LTF)
        df_htf = get_ohlcv(self.trading_bot.client, symbol, TF_HTF, LOOKBACK_HTF)
        
        if df_ltf is None or df_htf is None:
            return {"error": "Veri alınamadı"}
        
        # Analiz yap
        c, h, l = df_ltf['c'], df_ltf['h'], df_ltf['l']
        close = float(c.iloc[-1])
        
        # Teknik göstergeler
        rsi_val = float(rsi(c, 14).iloc[-1])
        adx_val = float(adx(h, l, c, 14).iloc[-1])
        atr_val = float(atr_wilder(h, l, c, 14).iloc[-1])
        
        # Bollinger Bands
        _, bb_upper, bb_lower, bandwidth, _ = bollinger(c, 20, 2.0)
        bw = float(bandwidth.iloc[-1])
        
        # Donchian
        dc_high, dc_low = donchian(h, l, 20)
        
        return {
            "symbol": symbol,
            "price": close,
            "rsi": rsi_val,
            "adx": adx_val,
            "atr_percent": (atr_val / close) * 100,
            "bandwidth": bw,
            "bb_upper": float(bb_upper.iloc[-1]),
            "bb_lower": float(bb_lower.iloc[-1]),
            "dc_high": float(dc_high.iloc[-1]),
            "dc_low": float(dc_low.iloc[-1]),
            "timestamp": datetime.now().isoformat()
        }
    
    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Web uygulamasını çalıştır"""
        log(f"🌐 Web uygulaması başlatılıyor: http://{host}:{port}")
        uvicorn.run(self.app, host=host, port=port)


# Signal model for API
class Signal(BaseModel):
    symbol: str
    side: str
    regime: str
    entry: float
    sl: float
    tp1: float
    tp2: float
    tp3: float
    score: float
    reason: str
    timestamp: str
